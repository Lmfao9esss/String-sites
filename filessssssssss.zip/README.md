# String Sites® — Portfolio Website

## Quick Setup (GitHub Pages)

### 1. Create a GitHub Repository
1. Go to [github.com/new](https://github.com/new)
2. Name it whatever you want (e.g., `stringsites` or `my-site`)
3. Set it to **Public**
4. Click **Create repository**

### 2. Upload Your Files
**Option A — Drag & Drop (easiest):**
1. On your new repo page, click **"uploading an existing file"**
2. Drag ALL the `.html` files and this `README.md` into the upload area
3. Click **Commit changes**

**Option B — Git CLI:**
```bash
cd path/to/your/site-folder
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### 3. Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages** (in the sidebar)
2. Under **Source**, select **Deploy from a branch**
3. Select **main** branch, **/ (root)** folder
4. Click **Save**
5. Wait 1-2 minutes — your site will be live at:
   `https://YOUR_USERNAME.github.io/YOUR_REPO/`

### 4. Custom Domain (optional)
1. Buy a domain (Namecheap, Cloudflare, etc.)
2. In repo Settings → Pages → **Custom domain**, type your domain
3. At your domain registrar, add these DNS records:
   - `A` → `185.199.108.153`
   - `A` → `185.199.109.153`
   - `A` → `185.199.110.153`
   - `A` → `185.199.111.153`
   - `CNAME` → `YOUR_USERNAME.github.io`
4. Check **Enforce HTTPS** in GitHub Pages settings

## Contact Form Setup
The contact form uses **FormSubmit.co** (free, no signup needed). The **first time** someone submits the form, you'll get a confirmation email from FormSubmit — click the activation link. After that, every submission goes straight to **Brushingmadeasy@gmail.com**.

## File List
| File | Description |
|------|-------------|
| `index.html` | Main homepage |
| `about.html` | About Nicolas Montemurro |
| `contact.html` | Contact form (sends email directly) |
| `service-web-design.html` | Web Design service page |
| `service-development.html` | Development service page |
| `service-seo.html` | SEO & Performance service page |
| `service-brand-strategy.html` | Brand Strategy service page |
| `service-content-copy.html` | Content & Copy service page |
| `service-ongoing-support.html` | Ongoing Support service page |

## Tech
Pure HTML, CSS, and JavaScript. Zero frameworks, zero dependencies, zero build tools. Just open any `.html` file in a browser and it works.
